# AI Translator — FINAL

Project Android siap di-upload ke GitHub dari HP.

Fitur:
- AI translation via OpenAI-compatible Chat Completions API
- Auto/source/target language
- Speech-to-text
- Text-to-speech
- Copy result
- Riwayat lokal
- Kamera OCR real-time dengan ML Kit
- Semua pengaturan API disimpan lokal

## Build dari HP tanpa PC

1. Buat repository GitHub baru.
2. Upload SEMUA isi folder project ini (jangan upload folder pembungkusnya).
3. Buka tab Actions.
4. Workflow "Build Android APK" akan berjalan.
5. Setelah selesai, buka run tersebut > Artifacts > download `AITranslator-debug-apk`.
6. Ekstrak ZIP artifact dan install APK di Android.

API key tidak disertakan. Masukkan milik sendiri di menu Pengaturan setelah aplikasi terpasang.

Untuk penggunaan publik, jangan menanam API key pribadi di APK; gunakan backend.
