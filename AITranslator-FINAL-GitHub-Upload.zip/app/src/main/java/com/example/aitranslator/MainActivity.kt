package com.example.aitranslator

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

data class Lang(val name:String, val code:String)
val LANGS = listOf(
    Lang("Auto","auto"), Lang("Indonesia","id"), Lang("English","en"),
    Lang("日本語","ja"), Lang("한국어","ko"), Lang("Español","es"), Lang("Français","fr")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var source by remember { mutableStateOf(LANGS[0]) }
    var target by remember { mutableStateOf(LANGS[2]) }
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showCamera by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf<Pair<String,String>>()) }

    val prefs = remember { ctx.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint","https://api.openai.com/v1/chat/completions") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model","gpt-4o-mini") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("apiKey","") ?: "") }

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        tts = TextToSpeech(ctx) {}
        onDispose { tts?.shutdown() }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val text = it.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) input = text
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) showCamera = true
    }

    MaterialTheme {
        if (showCamera) {
            CameraScreen(onText = { input = it; showCamera = false }, onClose = { showCamera = false })
        } else {
            Scaffold(topBar = {
                TopAppBar(title = { Text("AI Translator") },
                    actions = { TextButton(onClick={showSettings=true}) { Text("⚙") } })
            }) { pad ->
                Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LanguageMenu("Dari: ${source.name}", LANGS, source) { source = it }
                        LanguageMenu("Ke: ${target.name}", LANGS.filter { it.code!="auto" }, target) { target = it }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(input, { input=it }, Modifier.fillMaxWidth().weight(1f),
                        label={Text("Teks yang mau diterjemahkan")})
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Button(onClick={
                            val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            speechLauncher.launch(i)
                        }) { Text("🎤") }
                        Button(onClick={
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) showCamera=true
                            else cameraPermission.launch(Manifest.permission.CAMERA)
                        }) { Text("📷 OCR") }
                        Button(enabled=!busy && input.isNotBlank(), onClick={
                            busy=true
                            CoroutineScope(Dispatchers.IO).launch {
                                val r = translate(input, source, target, endpoint, model, apiKey)
                                withContext(Dispatchers.Main) {
                                    result=r; history=listOf(input to r)+history; busy=false
                                }
                            }
                        }) { Text(if(busy) "..." else "Terjemahkan") }
                    }
                    Spacer(Modifier.height(12.dp))
                    if(result.isNotBlank()) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(result)
                                Spacer(Modifier.height(8.dp))
                                Row {
                                    TextButton(onClick={ android.content.ClipboardManager::class.java; (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("translation",result)) }) { Text("Salin") }
                                    TextButton(onClick={ tts?.speak(result, TextToSpeech.QUEUE_FLUSH, null, "translation") }) { Text("🔊") }
                                }
                            }
                        }
                    }
                    if(history.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp)); Text("Riwayat", style=MaterialTheme.typography.titleMedium)
                        LazyColumn { items(history.take(10)) { (a,b) -> Text("$a\n→ $b", Modifier.padding(vertical=6.dp)) } }
                    }
                }
            }
        }
        if(showSettings) {
            AlertDialog(onDismissRequest={showSettings=false}, title={Text("Pengaturan AI")},
                text={
                    Column {
                        OutlinedTextField(endpoint,{endpoint=it},label={Text("Endpoint")},singleLine=true)
                        OutlinedTextField(model,{model=it},label={Text("Model")},singleLine=true)
                        OutlinedTextField(apiKey,{apiKey=it},label={Text("API Key")},singleLine=true)
                        Text("API key disimpan lokal di HP. Jangan membagikannya.")
                    }
                },
                confirmButton={TextButton(onClick={
                    prefs.edit().putString("endpoint",endpoint).putString("model",model).putString("apiKey",apiKey).apply()
                    showSettings=false
                }){Text("Simpan")}})
        }
    }
}

@Composable
fun LanguageMenu(label:String, options:List<Lang>, selected:Lang, onSelect:(Lang)->Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick={open=true}) { Text(label) }
        DropdownMenu(expanded=open,onDismissRequest={open=false}) {
            options.forEach { DropdownMenuItem(text={Text(it.name)}, onClick={onSelect(it);open=false}) }
        }
    }
}

suspend fun translate(text:String, source:Lang, target:Lang, endpoint:String, model:String, key:String):String {
    if(key.isBlank()) return "Masukkan API Key di Pengaturan terlebih dahulu."
    return try {
        val prompt = "Translate the following text from ${source.name} to ${target.name}. Preserve meaning and natural tone. Return only the translation.\n\n$text"
        val body=JSONObject().apply {
            put("model",model)
            put("messages", org.json.JSONArray().put(JSONObject().put("role","user").put("content",prompt)))
            put("temperature",0.2)
        }.toString()
        val req=Request.Builder().url(endpoint).addHeader("Authorization","Bearer $key")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        OkHttpClient().newCall(req).execute().use { r ->
            val raw=r.body?.string().orEmpty()
            if(!r.isSuccessful) return "Error ${r.code}: $raw"
            JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }
    } catch(e:Exception) { "Gagal menerjemahkan: ${e.message}" }
}

@Composable
fun CameraScreen(onText:(String)->Unit,onClose:()->Unit) {
    val ctx=LocalContext.current
    val previewView=remember { PreviewView(ctx) }
    val executor=remember { Executors.newSingleThreadExecutor() }
    var scanning by remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        val future=ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            val provider=future.get()
            val preview=Preview.Builder().build().also{it.surfaceProvider=previewView.surfaceProvider}
            val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            val recognizer=com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
            analysis.setAnalyzer(executor) { image ->
                if(scanning) {
                    val media=image.image
                    if(media!=null) {
                        val input=com.google.mlkit.vision.common.InputImage.fromMediaImage(media,image.imageInfo.rotationDegrees)
                        recognizer.process(input).addOnSuccessListener { res ->
                            if(res.text.isNotBlank()) { scanning=false; onText(res.text) }
                        }.addOnCompleteListener { image.close() }
                    } else image.close()
                } else image.close()
            }
            provider.unbindAll()
            provider.bindToLifecycle(ctx as ComponentActivity, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { executor.shutdown() }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView({previewView},Modifier.fillMaxSize())
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Button(onClick=onClose){Text("Tutup")}
            Text("Arahkan kamera ke teks. OCR otomatis membaca teks.")
        }
    }
}
